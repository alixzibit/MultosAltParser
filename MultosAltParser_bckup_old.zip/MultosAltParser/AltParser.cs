﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultosAltParser
{
    public class AltParser
    {
        private readonly BinaryReader _reader;
        public byte[] RawData { get; private set; }
        public AltFileHeader FileHeader { get; private set; }
        public TemplateHeader TemplateHeader { get; private set; }

        // Add properties for the various sections
        public byte[] Code { get; private set; }
        public ushort CodeSize { get; private set; }
        public byte[] Data { get; private set; }
        public ushort DataSize { get; private set; }
        public byte[] DirFileRec { get; private set; }
        public ushort DirFileRecSize { get; private set; }
        public byte[] FciRec { get; private set; }
        public ushort FciRecSize { get; private set; }
        public byte[] PdaRec { get; private set; }
        public ushort PdaRecSize { get; private set; }


        private ushort ReadUInt16BigEndian()
        {
            byte[] bytes = _reader.ReadBytes(2);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return BitConverter.ToUInt16(bytes, 0);
        }


        public AltParser(string filePath)
        {
            // Read entire file into memory
            RawData = File.ReadAllBytes(filePath);
            _reader = new BinaryReader(File.OpenRead(filePath));
        }

        public AltFileHeader ParseFileHeader()
        {
            var header = new AltFileHeader();

            // Read file type code - "CALT"
            byte[] fileTypeBytes = _reader.ReadBytes(4);
            header.FileTypeCode = System.Text.Encoding.ASCII.GetString(fileTypeBytes);

            if (header.FileTypeCode != "CALT")
                throw new InvalidDataException("Invalid ALT file - Expected 'CALT' header");

            header.FileProtectionMethodId = _reader.ReadByte();
            header.FileStructureMethodId = _reader.ReadByte();

            // Read Consignment ID (10 bytes ASCII)
            byte[] consignmentBytes = _reader.ReadBytes(10);
            header.ConsignmentId = System.Text.Encoding.ASCII.GetString(consignmentBytes);

            // Read File Date (4 bytes binary, not BCD)
            byte[] dateBytes = _reader.ReadBytes(4);
            // Convert binary date bytes to DateTime
            int year = dateBytes[0] * 256 + dateBytes[1];
            int month = dateBytes[2];
            int day = dateBytes[3];
            header.FileDate = new DateTime(year, month, day);

            // Read File Time (3 bytes binary, not BCD)
            byte[] timeBytes = _reader.ReadBytes(3);
            header.FileTime = new TimeSpan(timeBytes[0], timeBytes[1], timeBytes[2]);

            // Read Consignment File ID (8 bytes ASCII)
            byte[] consignmentFileBytes = _reader.ReadBytes(8);
            header.ConsignmentFileId = System.Text.Encoding.ASCII.GetString(consignmentFileBytes);

            // Read Issuer Identifier (4 bytes BCD)
            byte[] issuerIdBytes = _reader.ReadBytes(4);
            header.IssuerIdentifier = BitConverter.ToString(issuerIdBytes).Replace("-", "");

            header.Rfu = _reader.ReadBytes(4);
            header.MultosIssuerId = _reader.ReadUInt32();
            header.FileHash = _reader.ReadBytes(20);
            header.NumberOfTemplates = _reader.ReadUInt16();

            return header;
        }

        public TemplateHeader ParseTemplateHeader()
        {
            var header = new TemplateHeader();

            // Read Issuer Template ID (8 bytes)
            byte[] issuerTemplateBytes = _reader.ReadBytes(8);
            header.IssuerTemplateId = BitConverter.ToString(issuerTemplateBytes).Replace("-", "");

            // Read Software Product ID (8 bytes)
            byte[] softwareProductBytes = _reader.ReadBytes(8);
            header.SoftwareProductId = BitConverter.ToString(softwareProductBytes).Replace("-", "");

            header.KmaHashModulusId = _reader.ReadUInt16();
            header.CertificateSerialNumber = _reader.ReadBytes(3);
            header.ApplicationProviderPkKeySetId = _reader.ReadByte();
            header.IssuerMasterKeyIndex = _reader.ReadByte();
            header.AluDataRecordLength = _reader.ReadUInt32();
            header.PdaRecordLength = _reader.ReadUInt16();
            header.NumberOfPdaRecords = _reader.ReadUInt16();
            header.SessionDataLength = _reader.ReadUInt16();

            return header;
        }



        public AluDataRecord ParseAluDataRecord()
        {
            var aluData = new AluDataRecord();

            try
            {
                Debug.WriteLine($"Before MCD: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Validate and read MCD Number
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 8)
                    throw new EndOfStreamException("Not enough data for MCD Number");
                aluData.McdNumber = _reader.ReadBytes(8);

                Debug.WriteLine($"After MCD: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Read CodeRecordLength in big-endian
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 2)
                    throw new EndOfStreamException("Not enough data for CodeRecordLength");

                aluData.CodeRecordLength = ReadUInt16BigEndian();
                Debug.WriteLine($"CodeRecordLength: {aluData.CodeRecordLength:X4} ({aluData.CodeRecordLength} bytes)");

                // Validate and read Code Record
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < aluData.CodeRecordLength)
                    throw new EndOfStreamException($"Not enough data for CodeRecord (need {aluData.CodeRecordLength} bytes)");

                aluData.CodeRecord = _reader.ReadBytes(aluData.CodeRecordLength);
                Debug.WriteLine($"After CodeRecord: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Read DataRecordLength in big-endian
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 2)
                    throw new EndOfStreamException("Not enough data for DataRecordLength");

                aluData.DataRecordLength = ReadUInt16BigEndian();
                Debug.WriteLine($"DataRecordLength: {aluData.DataRecordLength:X4} ({aluData.DataRecordLength} bytes)");

                // Validate and read Data Record
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < aluData.DataRecordLength)
                    throw new EndOfStreamException($"Not enough data for DataRecord (need {aluData.DataRecordLength} bytes)");

                aluData.DataRecord = _reader.ReadBytes(aluData.DataRecordLength);
                Debug.WriteLine($"After DataRecord: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Read DirRecordLength in big-endian
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 2)
                    throw new EndOfStreamException("Not enough data for DirRecordLength");

                aluData.DirRecordLength = ReadUInt16BigEndian();
                Debug.WriteLine($"DirRecordLength: {aluData.DirRecordLength:X4} ({aluData.DirRecordLength} bytes)");

                // Validate and read DIR Record
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < aluData.DirRecordLength)
                    throw new EndOfStreamException($"Not enough data for DirRecord (need {aluData.DirRecordLength} bytes)");

                aluData.DirRecord = _reader.ReadBytes(aluData.DirRecordLength);
                Debug.WriteLine($"After DirRecord: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Read FciRecordLength in big-endian
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 2)
                    throw new EndOfStreamException("Not enough data for FciRecordLength");

                aluData.FciRecordLength = ReadUInt16BigEndian();
                Debug.WriteLine($"FciRecordLength: {aluData.FciRecordLength:X4} ({aluData.FciRecordLength} bytes)");

                // Validate and read FCI Record
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < aluData.FciRecordLength)
                    throw new EndOfStreamException($"Not enough data for FciRecord (need {aluData.FciRecordLength} bytes)");

                aluData.FciRecord = _reader.ReadBytes(aluData.FciRecordLength);
                Debug.WriteLine($"After FciRecord: Position={_reader.BaseStream.Position}, Length={_reader.BaseStream.Length}");

                // Read App Signature Length and KTU Length in big-endian
                if (_reader.BaseStream.Length - _reader.BaseStream.Position < 4)
                    throw new EndOfStreamException("Not enough data for AppSignature and KTU lengths");

                aluData.AppSignatureLength = ReadUInt16BigEndian();
                aluData.KtuLength = ReadUInt16BigEndian();

                return aluData;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error parsing ALU data record at position {_reader.BaseStream.Position}: {ex.Message}", ex);
            }
        }


        public bool ParseAlt(string filePath, ref string errorMessage)
        {
            try
            {
                // Parse File Header
                FileHeader = ParseFileHeader();

                // Parse Template Header
                TemplateHeader = ParseTemplateHeader();

                // Parse ALU Data sections
                ParseAluDataSections();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        //private void ParseAluDataSections()
        //{
        //    // Read Code Record
        //    CodeSize = _reader.ReadUInt16();
        //    Code = _reader.ReadBytes(CodeSize);

        //    // Read Data Record
        //    DataSize = _reader.ReadUInt16();
        //    Data = _reader.ReadBytes(DataSize);

        //    // Read DIR Record
        //    DirFileRecSize = _reader.ReadUInt16();
        //    DirFileRec = _reader.ReadBytes(DirFileRecSize);

        //    // Read FCI Record
        //    FciRecSize = _reader.ReadUInt16();
        //    FciRec = _reader.ReadBytes(FciRecSize);

        //    // Read PDA Records if present
        //    if (TemplateHeader.NumberOfPdaRecords > 0)
        //    {
        //        int pdaSize = TemplateHeader.NumberOfPdaRecords * 8; // Each PDA record is 8 bytes
        //        PdaRec = _reader.ReadBytes(pdaSize);
        //    }
        //}

        private void ParseAluDataSections()
        {
            Debug.WriteLine($"\nSection Starting Positions:");
            Debug.WriteLine($"Before Code Record: Position={_reader.BaseStream.Position}");

            // Read Code Record
            CodeSize = _reader.ReadUInt16();
            Code = _reader.ReadBytes(CodeSize);
            Debug.WriteLine($"Before Data Record: Position={_reader.BaseStream.Position}");

            // Read Data Record
            DataSize = _reader.ReadUInt16();
            Data = _reader.ReadBytes(DataSize);
            Debug.WriteLine($"Before DIR Record: Position={_reader.BaseStream.Position}");

            // Read DIR Record
            DirFileRecSize = _reader.ReadUInt16();
            DirFileRec = _reader.ReadBytes(DirFileRecSize);
            Debug.WriteLine($"Before FCI Record: Position={_reader.BaseStream.Position}");

            // Read FCI Record
            FciRecSize = _reader.ReadUInt16();
            FciRec = _reader.ReadBytes(FciRecSize);
            Debug.WriteLine($"Before PDA Records: Position={_reader.BaseStream.Position}");

            // Read PDA Records if present
            if (TemplateHeader.NumberOfPdaRecords > 0)
            {
                PdaRecSize = (ushort)(TemplateHeader.NumberOfPdaRecords * 8); // Each PDA record is 8 bytes
                PdaRec = _reader.ReadBytes(PdaRecSize);
                Debug.WriteLine($"After PDA Records: Position={_reader.BaseStream.Position}");
            }

            // Add section sizes information
            Debug.WriteLine($"\nSection Sizes:");
            Debug.WriteLine($"Code Record Size: {CodeSize}");
            Debug.WriteLine($"Data Record Size: {DataSize}");
            Debug.WriteLine($"DIR Record Size: {DirFileRecSize}");
            Debug.WriteLine($"FCI Record Size: {FciRecSize}");
            if (TemplateHeader.NumberOfPdaRecords > 0)
                Debug.WriteLine($"PDA Records Size: {PdaRecSize}");
        }


        public void Dispose()
        {
            _reader?.Dispose();
        }


        ///

        public class PdaRecord
        {
            public string No { get; set; }
            public string Pda { get; set; }
            public string Tag { get; set; }
            public string Length { get; set; }
            public string Address { get; set; }
            public string DataSource { get; set; }
            public string DataUsage { get; set; }
            public string DataFormat { get; set; }
            public string InputPresence { get; set; }
            public string LengthCheck { get; set; }
            public string DataCategory { get; set; }
            public string ProfileNo { get; set; }
            public string Interface { get; set; }

            public string PdaEx => Pda.Substring(0, 4);
            public string TagEx => !Tag.Substring(0, 2).Equals("00") ? Tag : Tag.Substring(2, 2);
            public string DataCategoryEx => !DataCategory.Equals("Application data") ? "fci" : "data";
            public string LengthCheckEx => !LengthCheck.Equals("Exact length") ? "max" : "exact";


            // PDA Constants
            private const byte PDA_DATA_SOURCE_MASK = 128;  // 0x80
            private const byte PDA_DATA_USAGE_MASK = 64;    // 0x40
            private const byte PDA_INTERFACE_TYPE_MASK = 48; // 0x30
            private const byte PDA_INTERFACE_TYPE_MASK_MCAR2 = 1;
            private const byte PDA_PROFILE_NUMBER_MASK = 15; // 0x0F
            private const byte PDA_PROFILE_NUMBER_MASK_MCAR2 = 6;
            private const byte PDA_DATA_FORMAT_MASK = 128;   // 0x80
            private const byte PDA_INPUT_PRESENCE_MASK = 64; // 0x40
            private const byte PDA_LENGTH_CHECK_MASK = 32;   // 0x20
            private const byte PDA_DATA_CATEGORY_MASK = 8;   // 0x08
            private const byte DATA_CATEGORY_DATA_RECORD = 0;
            private const byte DATA_CATEGORY_FCI_RECORD = 8;
            private const byte DATA_FORMAT_DATA_ONLY = 0;
            private const byte DATA_FORMAT_TLV = 128;

           

            private static string GetInterface(byte[] pdaRec, int index)
            {
                int interfaceValue = (pdaRec[index * 8] & 0x30) >> 4;
                switch (interfaceValue)
                {
                    case 0: return "-";
                    case 1: return "L";
                    case 2: return "C";
                    case 3: return "B";
                    default: return "-";
                }
            }
        }

    }
}
