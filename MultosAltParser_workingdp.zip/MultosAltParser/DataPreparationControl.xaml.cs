﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MultosAltParser
{
    /// <summary>
    /// Interaction logic for DataPreparationControl.xaml
    /// </summary>
    public partial class DataPreparationControl : UserControl
    {
        private List<PersonalizationRecord> _personalizationRecords;
        private AltParser _altParser;
        private AluDataRecord _aluData;
        private CardholderData _cdfData;
        private CdfParser _cdfParser = new CdfParser();
        private KeyData _keyData;
        private KeyDataParser _keyParser = new KeyDataParser();


        public DataPreparationControl()
        {
            InitializeComponent();
        }

        public void LoadAltData(AltParser parser, List<PdaRecord> pdaRecords, AluDataRecord aluData)
        {
            _altParser = parser;
            _aluData = aluData;

            Debug.WriteLine("Converting PDA records to Personalization records...");

            _personalizationRecords = pdaRecords
        .Where(p => p.DataUsage == "Input to ALU")  // Only get records that need input
        .Select(p =>
        {
            var record = new PersonalizationRecord
            {
                Tag = p.Tag,
                TagDescription = p.TagDescription,
                DataSource = p.DataSource,
                Address = p.Address,
                DataFormat = p.DataFormat,
                Length = p.Length,
                CurrentData = ExtractCurrentData(p)
            };

            // Category 1: CDF Data (Green)
            if (p.DataSource == "CDF")
            {
                record.Status = "Pending CDF";
                // PersonalizationData will be set when CDF is loaded
            }
            // Category 2: Keys Data (DarkSlateBlue)
            else if (IsKeyData(p.Tag))
            {
                record.Status = "Pending Keys";
                // PersonalizationData will be set when Keys are loaded
            }
            // Category 3: Default Data (Pass through current data)
            else
            {
                record.PersonalizationData = record.CurrentData;
                record.Status = "Ready (Default)";
            }

            return record;
        }).ToList();

            Debug.WriteLine("\nPersonalization Records Created:");
            foreach (var record in _personalizationRecords)
            {
                Debug.WriteLine($"Tag: {record.Tag}, Format: {record.DataFormat}, Address: {record.Address}");
            }

            dgPersonalization.ItemsSource = _personalizationRecords;
            
        }

        private bool IsKeyData(string tag)
        {
            var normalizedTag = tag.TrimStart('0');
            return new HashSet<string>
    {
        "DF42", "DF43", "DF44", 
        "DF60", "DF61", "9F46", "0090"
    }.Contains(normalizedTag);
        }

        private string ExtractCurrentData(PdaRecord pda)
        {
            try
            {
                int offset = Convert.ToInt32(pda.Address, 16);
                int length = Convert.ToInt32(pda.Length, 16);

                byte[] sourceData = pda.DataCategory == "FCI data" ?
                                 _aluData.FciRecord : _aluData.DataRecord;

                if (sourceData == null)
                    return "No data available";

                // For TLV format, extract just the value
                if (pda.DataFormat == "TLV format")
                {
                    if (offset + 2 <= sourceData.Length)
                    {
                        // Read the tag from the data (could be 1 or 2 bytes)
                        string tagInData = BitConverter.ToString(sourceData, offset, 1).Replace("-", "");
                        int tagLength = 1;

                        // Check if it's a 2-byte tag
                        if ((sourceData[offset] & 0x1F) == 0x1F)
                        {
                            tagLength = 2;
                            tagInData = BitConverter.ToString(sourceData, offset, 2).Replace("-", "");
                        }

                        // Read the length byte
                        int dataLength = sourceData[offset + tagLength];

                        // Read the actual value
                        if (offset + tagLength + 1 + dataLength <= sourceData.Length)
                        {
                            byte[] actualValue = new byte[dataLength];
                            Array.Copy(sourceData, offset + tagLength + 1, actualValue, 0, dataLength);
                            return BitConverter.ToString(actualValue).Replace("-", " ");
                        }
                        else
                        {
                            return "TLV structure incomplete";
                        }
                    }
                }
                else // Non-TLV format
                {
                    if (offset + length <= sourceData.Length)
                    {
                        byte[] data = new byte[length];
                        Array.Copy(sourceData, offset, data, 0, length);
                        return BitConverter.ToString(data).Replace("-", " ");
                    }
                    else
                    {
                        return "Data out of bounds";
                    }
                }

                return "Invalid data";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error extracting data: {ex.Message}");
                return $"Error: {ex.Message}";
            }
        }

        
                

        private async void BtnLoadCDF_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "CDF Files (*.xml)|*.xml|All files (*.*)|*.*",
                Title = "Select CDF File"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                await LoadCDFData(openFileDialog.FileName);
            }
        }

        private async Task LoadCDFData(string filename)
        {
            try
            {
                txtStatus.Text = "Loading CDF file...";
                _cdfData = await _cdfParser.ParseCdfXml(filename);

                // Update personalization data for CDF records
                foreach (var record in _personalizationRecords.Where(r => r.DataSource == "CDF"))
                {
                    string personalizationData = _cdfParser.GetPersonalizationData(
                        record.Tag,
                        _cdfData,
                        record.Length);

                    if (!string.IsNullOrEmpty(personalizationData))
                    {
                        record.PersonalizationData = personalizationData;
                        record.Status = "Ready";
                    }
                    else
                    {
                        record.Status = "Error: No data";
                    }
                }

                dgPersonalization.Items.Refresh();
                txtStatus.Text = "CDF data loaded successfully";
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error loading CDF";
                CustomMessageBox.Show($"Error loading CDF: {ex.Message}");
            }
        }

      

        private async void BtnCreateAlu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!IsDataReady())
                    return;

                var saveFileDialog = new SaveFileDialog
                {
                    Filter = "ALU Files (*.alu)|*.alu|All files (*.*)|*.*",
                    Title = "Save ALU File",
                    DefaultExt = "alu"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    txtStatus.Text = "Creating ALU file...";

                    // Use the already parsed data
                    var aluBuilder = new AluBuilder(_altParser, _aluData);
                    aluBuilder.InsertPersonalizedData(_personalizationRecords);

                    await aluBuilder.SaveAluFile(saveFileDialog.FileName);

                    txtStatus.Text = "ALU file created successfully";
                    CustomMessageBox.Show("ALU file has been created successfully!");
                }
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error creating ALU file";
                CustomMessageBox.Show($"Error creating ALU file:\n{ex.Message}");
            }
        }

        private bool ValidatePersonalizationData()
        {
            return _personalizationRecords
                .Where(r => r.DataUsage == "Input to ALU")
                .All(r => r.Status == "Ready");
        }

        private async void BtnLoadKeys_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Key Files (*.xml)|*.xml|All files (*.*)|*.*",
                Title = "Select Key File"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                await LoadKeyData(openFileDialog.FileName);
            }
        }

        private async Task LoadKeyData(string filename)
        {
            try
            {
                txtStatus.Text = "Loading key file...";
                _keyData = await _keyParser.ParseKeyXml(filename);

                // Update personalization data for key records
                foreach (var record in _personalizationRecords.Where(r => IsKeyData(r.Tag)))
                {
                    string normalizedTag = record.Tag.TrimStart('0');
                    if (_keyData.KeyValues.TryGetValue(normalizedTag, out string keyValue))
                    {
                        record.PersonalizationData = keyValue;
                        record.Status = "Ready";
                    }
                    else
                    {
                        record.Status = "Error: Key not found";
                    }
                }

                // Refresh DataGrid
                dgPersonalization.Items.Refresh();
                txtStatus.Text = "Key data loaded successfully";

                // Validate
                ValidateKeyLoading();
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error loading keys";
                CustomMessageBox.Show($"Error loading keys: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ValidateKeyLoading()
        {
            var missingKeys = _personalizationRecords
                .Where(r => IsKeyData(r.Tag) && r.Status != "Ready")
                .Select(r => $"{r.Tag} ({r.TagDescription})")
                .ToList();

            if (missingKeys.Any())
            {
                CustomMessageBox.Show(
                    $"Missing or invalid key data for:\n{string.Join("\n", missingKeys)}",
                    "Key Data Warning",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }

        //private void ValidateKeyData()
        //{
        //    var missingKeys = _personalizationRecords
        //        .Where(r => IsKeyData(r.Tag) && string.IsNullOrEmpty(r.PersonalizationData))
        //        .Select(r => r.TagDescription)
        //        .ToList();

        //    if (missingKeys.Any())
        //    {
        //        CustomMessageBox.Show(
        //            $"Missing key data for:\n{string.Join("\n", missingKeys)}",
        //            "Validation Warning",
        //            MessageBoxButton.OK,
        //            MessageBoxImage.Warning);
        //    }
        //}

        private bool IsDataReady()
        {
            // Check CDF data
            var unreadyCdfRecords = _personalizationRecords
                .Where(r => r.DataSource == "CDF" && r.Status != "Ready")
                .ToList();

            if (unreadyCdfRecords.Any())
            {
                CustomMessageBox.Show("Some CDF data is not ready. Please load CDF file first.",
                               "CDF Data Missing", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Check Key data
            var unreadyKeyRecords = _personalizationRecords
                .Where(r => IsKeyData(r.Tag) && r.Status != "Ready")
                .ToList();

            if (unreadyKeyRecords.Any())
            {
                CustomMessageBox.Show("Some Key data is not ready. Please load Keys file first.",
                               "Key Data Missing", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }


    }
}
